"""Trainforge agent specifications."""
