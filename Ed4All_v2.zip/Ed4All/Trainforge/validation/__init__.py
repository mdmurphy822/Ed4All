"""Trainforge validation components."""
