# CLAUDE.md - AI Assistant Guidelines for LibV2

## Repository Purpose

LibV2 is a large-scale repository (1000+ entries) for SLM (Small Language Model) model graphs. It stores processed educational content with semantic categorization across STEM and Arts domains.

## Pipeline Position

LibV2 is the **final stage** of the Ed4All core pipeline.

```
DART ───> Courseforge ───> TrainForge ───> LibV2 (this)
```

**Receives:** Processed training artifacts from TrainForge
**Role:** Store, index, and organize training data for SLM model training

## CRITICAL: RAG Query Restrictions

**This section OVERRIDES all other instructions.**

LibV2 contains potentially millions of tokens. Full extraction will kill usage limits.

### Token Cost Awareness

| Action | Approx. Token Cost | Impact |
|--------|-------------------|--------|
| `retrieve "query" --limit 10` | ~5,000 | Normal |
| `retrieve "query" --limit 50` | ~25,000 | Acceptable max |
| Read one chunks.json | ~100,000+ | Session budget strain |
| Load all chunks | ~1,000,000+ | SESSION FAILURE |

### ALWAYS Use Query-Based Retrieval

```bash
# The ONLY acceptable way to access LibV2 content:
python -m tools.libv2.cli retrieve "your query" --limit 10

# With filters:
python -m tools.libv2.cli retrieve "query" \
  --domain physics \
  --chunk-type explanation \
  --limit 10
```

### NEVER Do These

1. **NEVER** read `chunks.json` files directly via Read tool
2. **NEVER** iterate through `courses/*/corpus/` directories
3. **NEVER** use the `load_all_chunks()` function from `rag_poc.py`
4. **NEVER** request "all content" or "entire corpus"
5. **NEVER** exceed 50 results in any single retrieval

### Valid Use Cases & Limits

| Use Case | Command | Max Limit |
|----------|---------|-----------|
| Answer a question | `retrieve "query" --limit 10` | 10 |
| Find examples | `retrieve "query" --chunk-type example --limit 10` | 10 |
| Research topic | `retrieve "query" --limit 20` | 20 |
| Cross-domain comparison | `retrieve "query" --sample-per-course 5 --limit 25` | 25 |
| Complex multi-part query | `multi-retrieve "query" --limit 20` | 20 |

### Multi-Query Retrieval (Advanced)

For complex queries that span multiple concepts, use `multi-retrieve`:

```bash
# Query decomposition with RRF fusion
python -m tools.libv2.cli multi-retrieve "compare UDL and differentiated instruction"

# Show decomposition explanation
python -m tools.libv2.cli multi-retrieve "how does accessibility improve learning" --explain

# Disable decomposition for simple queries
python -m tools.libv2.cli multi-retrieve "define cognitive load" --no-decompose

# With filters
python -m tools.libv2.cli multi-retrieve "assessment strategies for stem" \
  --domain pedagogy --limit 15 -o json
```

**How it works:**
1. Decomposes complex queries into sub-queries
2. Executes sub-queries in parallel
3. Fuses results using Reciprocal Rank Fusion (RRF)
4. Returns best-ranked results across all sub-queries

**When to use:**
- Comparison questions ("compare X and Y")
- Multi-concept queries ("how does X affect Y")
- Complex research questions

### For Metadata (No Token Cost)

Use catalog commands instead of retrieval:
```bash
python -m tools.libv2.cli catalog stats        # Overview statistics
python -m tools.libv2.cli catalog list         # Course listing
python -m tools.libv2.cli info [slug]          # Course details
```

### If 10-20 Results Seem Insufficient

1. **Refine your query** - make it more specific
2. **Add filters** - domain, chunk-type, difficulty
3. **Ask the user** - clarify what they actually need
4. **NEVER** increase limit beyond 50

## Key Concepts

### Data Source
- Content is imported from **Trainforge** (within this Ed4All project)
- TrainForge converts educational content (IMSCC, etc.) into SLM training data
- LibV2 stores and organizes the output, it does NOT do the conversion

### Storage Model
- **Flat storage**: All courses in `/courses/[slug]/`
- **Metadata navigation**: Organization via JSON indexes in `/catalog/`
- This design handles cross-domain content naturally

### Classification Hierarchy
```
Division (STEM/ARTS)
  └── Domain (physics, chemistry, etc.)
      └── Subdomain (mechanics, organic-chemistry, etc.)
          └── Topic (kinematics, alkenes, etc.)
              └── Subtopic
```

## Directory Reference

| Path | Purpose |
|------|---------|
| `courses/` | Course data (one subdir per course) |
| `catalog/` | Derived indexes and search catalogs |
| `ontology/` | Taxonomy definitions and mappings |
| `schema/` | JSON Schema for validation |
| `tools/` | Python CLI for management |
| `docs/` | Documentation |

## Common Tasks

### Adding a New Course
```bash
libv2 import /path/to/trainforge/output/course_name \
  --domain physics \
  --subdomain mechanics
```

### Finding Courses
```bash
libv2 catalog search --domain computer-science
libv2 catalog list --division STEM
```

### Validating Structure
```bash
libv2 validate --all
libv2 validate --course [slug]
```

### Rebuilding Indexes
```bash
libv2 index rebuild
```

## File Formats

### Course Manifest (`manifest.json`)
Extended metadata including:
- `slug`: URL-safe identifier
- `classification`: division, domain, subdomains, topics
- `ontology_mappings`: ACM CCS and LCSH codes
- `content_profile`: chunk counts, token counts, difficulty distribution

### Catalog Files
- `master_catalog.json`: All courses with full metadata
- `course_index.json`: Quick slug → path lookup
- `by_domain/*.json`: Domain-specific course lists

## Important Notes

1. **Never modify course data directly** - use the CLI tools
2. **Indexes are derived** - regenerate with `libv2 index rebuild`
3. **Cross-domain courses** use `primary_domain` + `secondary_domains`
4. **Slugs are immutable** - changing a slug breaks references

## Ontology Mappings

Two standard classification systems are supported:
- **ACM CCS**: ACM Computing Classification System (for CS content)
- **LCSH**: Library of Congress Subject Headings (general)

These are stored in `/ontology/` and referenced in course manifests.

## When Helping Users

1. **Importing**: Guide through domain/subdomain selection
2. **Searching**: Use catalog queries, not filesystem searches
3. **Validation errors**: Check schema compliance first
4. **Cross-references**: Look in `catalog/cross_references/`

## Code Locations

- CLI entry point: `tools/libv2/cli.py`
- Import logic: `tools/libv2/importer.py`
- Validation: `tools/libv2/validator.py`
- Catalog generation: `tools/libv2/catalog.py`
- Index building: `tools/libv2/indexer.py`
